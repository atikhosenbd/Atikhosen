
import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HomePage from "@/pages/HomePage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";
import DashboardPage from "@/pages/DashboardPage";
import CoursesPage from "@/pages/CoursesPage";
import CourseDetailsPage from "@/pages/CourseDetailsPage";
import StudentsPage from "@/pages/StudentsPage";
import InstructorsPage from "@/pages/InstructorsPage";
import InstructorProfilePage from "@/pages/InstructorProfilePage";
import AboutPage from "@/pages/AboutPage";
import ContactPage from "@/pages/ContactPage";
import BlogPage from "@/pages/BlogPage";
import BlogDetailsPage from "@/pages/BlogDetailsPage";
import ErrorPage from "@/pages/ErrorPage";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const loggedInStatus = localStorage.getItem("isLoggedIn") === "true";
    setIsLoggedIn(loggedInStatus);
  }, []);

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-background">
        <Header isLoggedIn={isLoggedIn} />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            
            <Route path="/courses" element={<CoursesPage />} />
            <Route path="/courses/:courseId" element={<CourseDetailsPage />} />
            
            <Route path="/students" element={<StudentsPage />} /> 
            
            <Route path="/instructors" element={<InstructorsPage />} />
            <Route path="/instructors/:instructorId" element={<InstructorProfilePage />} />

            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:postId" element={<BlogDetailsPage />} />
            
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />

            {/* Basic static routes for footer links - can be expanded later */}
            <Route path="/help-center" element={<ErrorPage statusCode={501} message="Help Center Coming Soon!" />} />
            <Route path="/faq" element={<ErrorPage statusCode={501} message="FAQ Page Coming Soon!" />} />
            <Route path="/privacy-policy" element={<ErrorPage statusCode={501} message="Privacy Policy Page Coming Soon!" />} />
            <Route path="/terms-of-service" element={<ErrorPage statusCode={501} message="Terms of Service Page Coming Soon!" />} />
            <Route path="/sitemap" element={<ErrorPage statusCode={501} message="Sitemap Page Coming Soon!" />} />


            <Route path="*" element={<ErrorPage />} />
          </Routes>
        </main>
        <Footer />
        <Toaster />
      </div>
    </Router>
  );
}

export default App;
