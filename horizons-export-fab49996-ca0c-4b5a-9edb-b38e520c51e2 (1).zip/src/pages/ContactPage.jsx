
import React from "react";
import { motion } from "framer-motion";
import PageHeader from "@/components/PageHeader";
import ContactInfoItem from "@/components/contact/ContactInfoItem";
import ContactForm from "@/components/contact/ContactForm";
import FaqSection from "@/components/contact/FaqSection";
import LocationMap from "@/components/contact/LocationMap";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

const contactInfo = [
  { icon: <Phone />, title: "Call Us", details: ["Sales: +1 (555) 123-0000", "Support: +1 (555) 123-0001"] },
  { icon: <Mail />, title: "Email Us", details: ["General: info@edcare.com", "Support: support@edcare.com"] },
  { icon: <MapPin />, title: "Our Office", details: ["123 Learning Ave, Education City, EC 54321"] },
  { icon: <Clock />, title: "Working Hours", details: ["Mon - Fri: 9 AM - 6 PM", "Sat: 10 AM - 3 PM"] }
];

const ContactPage = () => {
  const breadcrumbs = [{ label: "Home", link: "/" }, { label: "Contact Us" }];

  return (
    <>
      <PageHeader title="Get in Touch" breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <motion.p 
          className="text-center text-lg text-muted-foreground max-w-2xl mx-auto mb-12"
          initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}
        >
          We're here to help! Whether you have questions about our courses, need support, or want to partner with us, feel free to reach out.
        </motion.p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {contactInfo.map((item, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 + 0.2 }}
            >
              <ContactInfoItem {...item} />
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-5 gap-10 items-start">
          <motion.div className="lg:col-span-3" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.3 }}>
            <ContactForm />
          </motion.div>
          <motion.div className="lg:col-span-2 space-y-8" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.4 }}>
            <FaqSection />
          </motion.div>
        </div>
        
        <motion.div className="mt-16" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.5 }}>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8 text-center">Find Us On The Map</h2>
          <LocationMap />
        </motion.div>
      </div>
    </>
  );
};

export default ContactPage;
