
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, SlidersHorizontal, List, Grid } from "lucide-react";
import CourseCard from "@/components/CourseCard";
import PageHeader from "@/components/PageHeader";

const mockCourses = [
  { id: '1', title: 'Web Development Bootcamp', category: 'Development', description: 'Comprehensive bootcamp covering HTML, CSS, JavaScript, React, and Node.js.', instructor: { name: 'Michael Brown' }, duration: '24 Weeks', students: 1500, level: 'All Levels', rating: 4.8, reviews: 512, image: 'web development bootcamp course' },
  { id: '2', title: 'Data Science with Python', category: 'Science', description: 'Learn data analysis, visualization, and machine learning using Python.', instructor: { name: 'Dr. Emily White' }, duration: '16 Weeks', students: 1120, level: 'Intermediate', rating: 4.9, reviews: 380, image: 'data science python course' },
  { id: '3', title: 'Digital Illustration: From Sketch to Vector', category: 'Art & Design', description: 'Master digital illustration techniques using popular software.', instructor: { name: 'Olivia Green' }, duration: '10 Weeks', students: 850, level: 'Beginner', rating: 4.7, reviews: 210, image: 'digital illustration course' },
  { id: '4', title: 'Financial Accounting Fundamentals', category: 'Business', description: 'Understand core accounting principles and financial statement analysis.', instructor: { name: 'Robert Davis' }, duration: '12 Weeks', students: 920, level: 'Beginner', rating: 4.6, reviews: 190, image: 'financial accounting course' },
  { id: '5', title: 'Introduction to Music Theory', category: 'Music', description: 'Learn the building blocks of music, including scales, chords, and harmony.', instructor: { name: 'Sophia Loren' }, duration: '8 Weeks', students: 600, level: 'Beginner', rating: 4.8, reviews: 150, image: 'music theory course' },
  { id: '6', title: 'Modern European History', category: 'Academics', description: 'Explore key events and developments in European history from the Renaissance to today.', instructor: { name: 'Dr. William Black' }, duration: '14 Weeks', students: 780, level: 'Intermediate', rating: 4.5, reviews: 120, image: 'european history course' },
];

const CoursesPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [viewMode, setViewMode] = useState("grid"); // "grid" or "list"

  const categories = ["All", "Development", "Science", "Art & Design", "Business", "Music", "Academics"];

  const filteredCourses = mockCourses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          course.instructor.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory.toLowerCase() === "all" || course.category.toLowerCase() === selectedCategory.toLowerCase();
    return matchesSearch && matchesCategory;
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };
  
  const breadcrumbs = [
    { label: "Home", link: "/" },
    { label: "Courses" }
  ];

  return (
    <>
      <PageHeader title="Our Courses" breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
          <div className="relative w-full md:w-1/3">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search courses..."
              className="pl-10 h-12 text-base"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full sm:w-[180px] h-12 text-base">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="outline" size="lg" className="h-12">
              <SlidersHorizontal className="h-5 w-5 mr-2" /> Filters
            </Button>
            <div className="flex gap-1">
              <Button variant={viewMode === 'grid' ? 'default' : 'outline'} size="icon" onClick={() => setViewMode('grid')} className="h-12 w-12">
                <Grid className="h-5 w-5" />
              </Button>
              <Button variant={viewMode === 'list' ? 'default' : 'outline'} size="icon" onClick={() => setViewMode('list')} className="h-12 w-12">
                <List className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {filteredCourses.length === 0 ? (
          <div className="text-center py-12">
            <Search className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-2xl font-medium mb-2">No Courses Found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filter criteria.</p>
          </div>
        ) : (
          <motion.div 
            className={`grid gap-8 ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'}`}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {filteredCourses.map((course) => (
              <motion.div key={course.id} variants={itemVariants}>
                <CourseCard course={course} />
              </motion.div>
            ))}
          </motion.div>
        )}

        <div className="mt-12 flex justify-center">
          <Button size="lg" variant="outline">Load More Courses</Button>
        </div>
      </div>
    </>
  );
};

export default CoursesPage;
