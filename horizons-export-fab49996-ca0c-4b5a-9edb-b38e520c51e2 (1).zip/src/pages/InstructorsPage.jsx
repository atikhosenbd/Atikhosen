
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import InstructorCard from '@/components/InstructorCard';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, SlidersHorizontal } from 'lucide-react';

const mockInstructors = [
  { id: '1', name: 'Dr. John Smith', title: 'Lead Data Scientist', courses: 12, students: 1500, rating: 4.9, image: 'instructor john smith', isVerified: true },
  { id: '2', name: 'Alice Johnson', title: 'Senior Software Engineer', courses: 8, students: 1200, rating: 4.8, image: 'instructor alice johnson', isVerified: true },
  { id: '3', name: 'Robert Brown', title: 'Marketing Guru', courses: 15, students: 2200, rating: 4.7, image: 'instructor robert brown', isVerified: false },
  { id: '4', name: 'Emily Davis', title: 'UX Design Lead', courses: 10, students: 950, rating: 4.9, image: 'instructor emily davis', isVerified: true },
  { id: '5', name: 'Michael Wilson', title: 'Cybersecurity Expert', courses: 7, students: 1100, rating: 4.6, image: 'instructor michael wilson', isVerified: false },
  { id: '6', name: 'Sophia Garcia', title: 'AI Researcher', courses: 9, students: 1350, rating: 4.8, image: 'instructor sophia garcia', isVerified: true },
];

const InstructorsPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name-asc");

  const breadcrumbs = [
    { label: "Home", link: "/" },
    { label: "Instructors" }
  ];

  const filteredInstructors = mockInstructors
    .filter(instructor => 
      instructor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      instructor.title.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === "name-asc") return a.name.localeCompare(b.name);
      if (sortBy === "name-desc") return b.name.localeCompare(a.name);
      if (sortBy === "courses") return b.courses - a.courses;
      if (sortBy === "students") return b.students - a.students;
      return 0;
    });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <>
      <PageHeader title="Meet Our Expert Instructors" breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
          <div className="relative w-full md:w-1/3">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search instructors..."
              className="pl-10 h-12 text-base"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full sm:w-[200px] h-12 text-base">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                <SelectItem value="courses">Most Courses</SelectItem>
                <SelectItem value="students">Most Students</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="lg" className="h-12">
              <SlidersHorizontal className="h-5 w-5 mr-2" /> Advanced Filters
            </Button>
          </div>
        </div>

        {filteredInstructors.length === 0 ? (
          <div className="text-center py-12">
            <Search className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-2xl font-medium mb-2">No Instructors Found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filter criteria.</p>
          </div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {filteredInstructors.map((instructor) => (
              <motion.div key={instructor.id} variants={itemVariants}>
                <InstructorCard instructor={instructor} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </>
  );
};

export default InstructorsPage;
