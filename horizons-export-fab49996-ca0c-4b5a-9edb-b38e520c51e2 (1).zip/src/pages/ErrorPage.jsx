
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

const ErrorPage = ({ statusCode = 404, message = "Oops! The page you're looking for doesn't exist." }) => {
  const errorMessages = {
    404: "Oops! Page Not Found.",
    500: "Oops! Server Error.",
    403: "Oops! Access Denied.",
  };

  const errorDescriptions = {
    404: "The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.",
    500: "We're experiencing some technical difficulties. Please try again later.",
    403: "You don't have permission to access this page.",
  };
  
  const displayMessage = errorMessages[statusCode] || message;
  const displayDescription = errorDescriptions[statusCode] || "An unexpected error has occurred.";

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-muted/30 text-center px-4 section-padding">
      <motion.div
        initial={{ opacity: 0, y: -50, scale: 0.5 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, type: "spring", stiffness: 120 }}
        className="max-w-md"
      >
        <AlertTriangle className="mx-auto h-24 w-24 text-destructive mb-8" />
        
        <h1 className="text-6xl md:text-8xl font-extrabold text-primary mb-4">
          {statusCode}
        </h1>
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6">
          {displayMessage}
        </h2>
        <p className="text-muted-foreground text-lg mb-10">
          {displayDescription}
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Link to="/">
              <Home className="mr-2 h-5 w-5" /> Go Back Home
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link to="/contact">
              Contact Support
            </Link>
          </Button>
        </div>
      </motion.div>
      
      <motion.div 
        className="absolute -bottom-20 -left-20 w-72 h-72 bg-primary/10 rounded-full filter blur-3xl opacity-50 animate-blob"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.5 }}
      ></motion.div>
      <motion.div 
        className="absolute -top-20 -right-20 w-72 h-72 bg-green-500/10 rounded-full filter blur-3xl opacity-50 animate-blob animation-delay-2000"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.7 }}
      ></motion.div>
    </div>
  );
};

export default ErrorPage;
