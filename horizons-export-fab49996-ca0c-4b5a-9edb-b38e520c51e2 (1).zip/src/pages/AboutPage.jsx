
import React from "react";
import AboutHero from "@/components/about/AboutHero";
import OurStorySection from "@/components/about/OurStorySection";
import MissionAndValues from "@/components/about/MissionAndValues";
import TeamSection from "@/components/about/TeamSection";
import WhyChooseUsSection from "@/components/about/WhyChooseUsSection";
import CallToAction from "@/components/home/CallToAction"; // Reusing CTA

const AboutPage = () => {
  return (
    <div>
      <AboutHero />
      <OurStorySection />
      <MissionAndValues />
      <TeamSection />
      <WhyChooseUsSection />
      <CallToAction />
    </div>
  );
};

export default AboutPage;
