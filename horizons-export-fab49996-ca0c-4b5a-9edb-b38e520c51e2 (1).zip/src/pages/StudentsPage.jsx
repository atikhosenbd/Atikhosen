
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, PlusCircle, Download } from "lucide-react";
import StudentDirectoryCard from "@/components/students/StudentDirectoryCard";
import PageHeader from "@/components/PageHeader";

const mockStudents = [
  { id: 1, name: "Emma Wilson", email: "emma.wilson@example.com", phone: "(555) 123-4567", grade: "10th Grade", courses: ["Mathematics", "Physics"], attendance: "95%", avatar: "EW" },
  { id: 2, name: "James Brown", email: "james.brown@example.com", phone: "(555) 234-5678", grade: "11th Grade", courses: ["Chemistry", "History"], attendance: "92%", avatar: "JB" },
  { id: 3, name: "Olivia Smith", email: "olivia.smith@example.com", phone: "(555) 345-6789", grade: "9th Grade", courses: ["Algebra", "Art"], attendance: "98%", avatar: "OS" },
  { id: 4, name: "Noah Johnson", email: "noah.johnson@example.com", phone: "(555) 456-7890", grade: "12th Grade", courses: ["Calculus", "CompSci"], attendance: "90%", avatar: "NJ" },
  { id: 5, name: "Sophia Davis", email: "sophia.davis@example.com", phone: "(555) 567-8901", grade: "10th Grade", courses: ["Biology", "PE"], attendance: "94%", avatar: "SD" },
  { id: 6, name: "Liam Miller", email: "liam.miller@example.com", phone: "(555) 678-9012", grade: "11th Grade", courses: ["Literature", "Spanish"], attendance: "91%", avatar: "LM" },
];

const StudentsPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGrade, setSelectedGrade] = useState("All Grades");

  const breadcrumbs = [{ label: "Home", link: "/" }, { label: "Students" }];
  const grades = ["All Grades", "9th Grade", "10th Grade", "11th Grade", "12th Grade"];

  const filteredStudents = mockStudents.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          student.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGrade = selectedGrade === "All Grades" || student.grade === selectedGrade;
    return matchesSearch && matchesGrade;
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
  };
  const itemVariants = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };

  return (
    <>
      <PageHeader title="Student Directory" breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <Card className="mb-8 shadow">
          <CardHeader className="pb-4 border-b">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
              <CardTitle className="text-xl">Manage Students</CardTitle>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button variant="outline" size="sm"> <Download className="h-4 w-4 mr-2" /> Export List </Button>
                <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground"> <PlusCircle className="h-4 w-4 mr-2" /> Add New Student </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-6">
              <Tabs value={selectedGrade} onValueChange={setSelectedGrade} className="w-full md:w-auto">
                <TabsList className="grid grid-cols-3 sm:grid-cols-5 h-auto">
                  {grades.map(grade => (
                    <TabsTrigger key={grade} value={grade} className="text-xs sm:text-sm px-2 py-1.5">{grade}</TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
              <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                <div className="relative flex-grow md:flex-grow-0">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search students..." className="pl-9 h-10 text-sm w-full sm:w-[220px]" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                </div>
                <Select defaultValue="name-asc">
                  <SelectTrigger className="w-full sm:w-[160px] h-10 text-sm"> <SelectValue placeholder="Sort by" /> </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                    <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon" className="h-10 w-10 hidden sm:flex"> <Filter className="h-4 w-4" /> </Button>
              </div>
            </div>
            {filteredStudents.length === 0 ? (
              <div className="text-center py-10"><p className="text-muted-foreground">No students found matching your criteria.</p></div>
            ) : (
            <motion.div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" variants={containerVariants} initial="hidden" animate="visible">
              {filteredStudents.map((student) => (
                <motion.div key={student.id} variants={itemVariants}>
                  <StudentDirectoryCard student={student} />
                </motion.div>
              ))}
            </motion.div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default StudentsPage;
