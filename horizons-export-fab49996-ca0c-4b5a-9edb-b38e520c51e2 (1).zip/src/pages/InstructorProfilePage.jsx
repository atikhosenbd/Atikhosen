
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import CourseCard from '@/components/CourseCard';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Star, BookOpen, Users, Linkedin, Twitter, Globe, Mail } from 'lucide-react';

const mockInstructor = {
  id: '1',
  name: 'Dr. John Smith',
  title: 'Lead Data Scientist & AI Researcher',
  bio: 'Dr. John Smith is a renowned expert in Data Science and Artificial Intelligence with over 15 years of academic and industry experience. He holds a PhD in Computer Science from Stanford University and has published numerous papers in top-tier journals. Dr. Smith is passionate about making complex topics accessible and has taught thousands of students worldwide. His courses focus on practical application and real-world problem-solving.',
  image: 'instructor john smith detailed portrait',
  avatar: 'JS',
  courses: 12,
  students: 1500,
  rating: 4.9,
  reviews: 350,
  isVerified: true,
  socials: {
    linkedin: 'https://linkedin.com/in/johnsmith',
    twitter: 'https://twitter.com/johnsmith',
    website: 'https://johnsmith.com'
  },
  expertise: ['Data Science', 'Machine Learning', 'Artificial Intelligence', 'Python', 'Statistics'],
  instructorCourses: [
    { id: 'ds1', title: 'Complete Data Science Bootcamp 2025', category: 'Science', description: 'Master Data Science and Machine Learning with Python.', instructor: { name: 'Dr. John Smith' }, duration: '30 Weeks', students: 800, level: 'All Levels', rating: 4.9, reviews: 200, image: 'data science bootcamp course' },
    { id: 'ml1', title: 'Machine Learning A-Z™: Hands-On Python & R In Data Science', category: 'Science', description: 'Learn to create Machine Learning Algorithms in Python and R.', instructor: { name: 'Dr. John Smith' }, duration: '25 Weeks', students: 500, level: 'Intermediate', rating: 4.8, reviews: 100, image: 'machine learning course' },
    { id: 'ai1', title: 'Artificial Intelligence: Reinforcement Learning in Python', category: 'Science', description: 'Develop AI models for real-world applications using Reinforcement Learning.', instructor: { name: 'Dr. John Smith' }, duration: '20 Weeks', students: 200, level: 'Advanced', rating: 4.9, reviews: 50, image: 'ai reinforcement learning course' },
  ]
};


const InstructorProfilePage = () => {
  const { instructorId } = useParams();
  const instructor = mockInstructor; // Fetch instructor by ID in real app

  if (!instructor) return <div>Instructor not found.</div>;

  const breadcrumbs = [
    { label: "Home", link: "/" },
    { label: "Instructors", link: "/instructors" },
    { label: instructor.name }
  ];

  return (
    <>
      <PageHeader title={instructor.name} breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="mb-10 shadow-lg">
            <CardContent className="p-6 md:p-10">
              <div className="grid md:grid-cols-3 gap-8 items-center">
                <div className="md:col-span-1 flex flex-col items-center md:items-start">
                  <Avatar className="w-40 h-40 mb-6 border-4 border-primary/30">
                    <img  className="w-full h-full object-cover" alt={instructor.name} src="https://images.unsplash.com/photo-1635251595512-dc52146d5ae8" />
                    <AvatarFallback className="text-5xl">{instructor.avatar}</AvatarFallback>
                  </Avatar>
                  {instructor.isVerified && (
                    <div className="flex items-center bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium mb-4">
                      <Star size={16} className="mr-1.5 fill-current" /> Verified Instructor
                    </div>
                  )}
                  <div className="flex space-x-3">
                    {instructor.socials.linkedin && <a href={instructor.socials.linkedin} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary"><Linkedin size={22}/></a>}
                    {instructor.socials.twitter && <a href={instructor.socials.twitter} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary"><Twitter size={22}/></a>}
                    {instructor.socials.website && <a href={instructor.socials.website} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary"><Globe size={22}/></a>}
                    <a href={`mailto:${instructor.name.toLowerCase().replace(' ', '.')}@devsdeen.com`} className="text-muted-foreground hover:text-primary"><Mail size={22}/></a>
                  </div>
                </div>
                <div className="md:col-span-2">
                  <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-1">{instructor.name}</h1>
                  <p className="text-primary text-lg font-medium mb-4">{instructor.title}</p>
                  <div className="flex flex-wrap gap-x-6 gap-y-3 text-muted-foreground mb-6">
                    <div className="flex items-center"><Star size={18} className="mr-1.5 text-yellow-400 fill-yellow-400" /> {instructor.rating} Average Rating ({instructor.reviews} reviews)</div>
                    <div className="flex items-center"><BookOpen size={18} className="mr-1.5 text-primary" /> {instructor.courses} Courses</div>
                    <div className="flex items-center"><Users size={18} className="mr-1.5 text-primary" /> {instructor.students} Students</div>
                  </div>
                  <p className="text-muted-foreground leading-relaxed mb-6">{instructor.bio}</p>
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2 text-foreground">Areas of Expertise:</h4>
                    <div className="flex flex-wrap gap-2">
                      {instructor.expertise.map(skill => (
                        <span key={skill} className="bg-secondary text-secondary-foreground px-3 py-1 text-sm rounded-full">{skill}</span>
                      ))}
                    </div>
                  </div>
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">Send Message</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">Courses by {instructor.name}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {instructor.instructorCourses.map((course, index) => (
                 <motion.div
                    key={course.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <CourseCard course={course} />
                  </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default InstructorProfilePage;
