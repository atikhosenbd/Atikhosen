
import React from "react";
import Hero from "@/components/home/Hero";
import Categories from "@/components/home/Categories";
import PopularCourses from "@/components/home/PopularCourses";
import AboutSummary from "@/components/home/AboutSummary";
import Testimonials from "@/components/home/Testimonials";
import HomeBlogSection from "@/components/home/HomeBlogSection";
import CallToAction from "@/components/home/CallToAction";

const HomePage = () => {
  return (
    <div>
      <Hero />
      <Categories />
      <PopularCourses />
      <AboutSummary />
      <Testimonials />
      <HomeBlogSection />
      <CallToAction />
    </div>
  );
};

export default HomePage;
