
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageHeader from '@/components/PageHeader';
import { Calendar, Clock, Users, BarChart2, Star, CheckCircle, PlayCircle, Download, Share2, Heart, Award } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";

const mockCourse = {
  id: '1',
  title: 'Web Development Bootcamp',
  category: 'Development',
  description: 'A comprehensive bootcamp covering HTML, CSS, JavaScript, React, Node.js, and more. Perfect for beginners and aspiring full-stack developers. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
  longDescription: 'Dive deep into the world of web development with our immersive bootcamp. This course is designed to take you from zero to hero, equipping you with the skills needed to build modern, responsive web applications. We cover frontend technologies like HTML5, CSS3, JavaScript (ES6+), and React, as well as backend development with Node.js, Express, and database interactions. You\'ll work on real-world projects, build a professional portfolio, and receive career guidance. Our expert instructors provide personalized feedback and support throughout your learning journey.',
  instructor: { id: 'inst1', name: 'Michael Brown', title: 'Lead Web Developer', bio: 'Michael is a seasoned web developer with over 10 years of experience building complex web applications for startups and enterprise clients.', avatar: 'MB' },
  duration: '24 Weeks',
  students: 1500,
  level: 'All Levels',
  rating: 4.8,
  reviews: 512,
  price: 499.99,
  originalPrice: 799.99,
  lastUpdated: 'April 2025',
  language: 'English',
  image: 'web development bootcamp detailed course image',
  whatYouWillLearn: [
    'Build responsive websites with HTML, CSS, and JavaScript.',
    'Develop dynamic web applications using React and Node.js.',
    'Understand database design and management.',
    'Deploy applications to cloud platforms.',
    'Master version control with Git and GitHub.',
  ],
  requirements: [
    'A computer with internet access.',
    'Basic computer literacy.',
    'No prior programming experience required.',
  ],
  curriculum: [
    { title: 'Module 1: Introduction to Web Development', lessons: 10, duration: '2 hours' },
    { title: 'Module 2: HTML5 Fundamentals', lessons: 15, duration: '4 hours' },
    { title: 'Module 3: CSS3 and Responsive Design', lessons: 20, duration: '6 hours' },
    { title: 'Module 4: JavaScript Essentials', lessons: 25, duration: '8 hours' },
    { title: 'Module 5: React for Frontend Development', lessons: 30, duration: '10 hours' },
    { title: 'Module 6: Node.js and Express for Backend', lessons: 25, duration: '8 hours' },
    { title: 'Module 7: Databases (MongoDB/SQL)', lessons: 15, duration: '5 hours' },
    { title: 'Module 8: Final Project and Deployment', lessons: 10, duration: '12 hours' },
  ],
  studentFeedback: [
    { name: 'Alice Wonderland', rating: 5, comment: 'Amazing course! Learned so much and built a great portfolio.', avatar: 'AW' },
    { name: 'Bob The Builder', rating: 4, comment: 'Challenging but very rewarding. Instructors were helpful.', avatar: 'BB' },
    { name: 'Charlie Brown', rating: 5, comment: 'Highly recommend for anyone serious about web development.', avatar: 'CB' },
  ]
};

const CourseDetailsPage = () => {
  const { courseId } = useParams();
  const course = mockCourse; // In a real app, fetch course by ID

  if (!course) {
    return <div>Course not found</div>;
  }

  const breadcrumbs = [
    { label: "Home", link: "/" },
    { label: "Courses", link: "/courses" },
    { label: course.title }
  ];

  const calculateDiscountPercentage = () => {
    if (course.originalPrice && course.price < course.originalPrice) {
      return Math.round(((course.originalPrice - course.price) / course.originalPrice) * 100);
    }
    return 0;
  };
  const discountPercentage = calculateDiscountPercentage();


  return (
    <>
      <PageHeader title={course.title} breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <motion.div initial={{ opacity: 0, y:20 }} animate={{ opacity: 1, y:0 }} transition={{ duration: 0.5 }}>
              <div className="relative aspect-video rounded-lg overflow-hidden shadow-lg mb-6">
                <img  className="w-full h-full object-cover" alt={course.title} src="https://images.unsplash.com/photo-1512820790803-83ca734da794" />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <Button variant="ghost" size="icon" className="h-20 w-20 bg-white/30 hover:bg-white/50 rounded-full">
                    <PlayCircle className="h-12 w-12 text-white" />
                  </Button>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 items-center mb-6 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Avatar className="h-8 w-8 mr-2">
                    <img  className="w-full h-full object-cover" alt={course.instructor.name} src="https://images.unsplash.com/photo-1543585959-06f5b68ad5dc" />
                    <AvatarFallback>{course.instructor.avatar}</AvatarFallback>
                  </Avatar>
                  Instructor: <Link to={`/instructors/${course.instructor.id}`} className="ml-1 text-primary hover:underline">{course.instructor.name}</Link>
                </div>
                <div className="flex items-center"><Star size={16} className="mr-1 text-yellow-400 fill-yellow-400" /> {course.rating} ({course.reviews} reviews)</div>
                <div className="flex items-center"><Users size={16} className="mr-1" /> {course.students} students</div>
                <div className="flex items-center"><Calendar size={16} className="mr-1" /> Last updated: {course.lastUpdated}</div>
              </div>

              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="mb-6">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                  <TabsTrigger value="instructor">Instructor</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6">
                  <Card>
                    <CardHeader><CardTitle>Course Description</CardTitle></CardHeader>
                    <CardContent><p className="text-muted-foreground leading-relaxed">{course.longDescription || course.description}</p></CardContent>
                  </Card>
                  <Card>
                    <CardHeader><CardTitle>What You'll Learn</CardTitle></CardHeader>
                    <CardContent>
                      <ul className="grid md:grid-cols-2 gap-x-6 gap-y-3">
                        {course.whatYouWillLearn.map((item, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 shrink-0" />
                            <span className="text-muted-foreground">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader><CardTitle>Requirements</CardTitle></CardHeader>
                    <CardContent>
                      <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                        {course.requirements.map((item, index) => (<li key={index}>{item}</li>))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="curriculum">
                  <Card>
                    <CardHeader><CardTitle>Course Curriculum</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                      {course.curriculum.map((module, index) => (
                        <div key={index} className="p-4 border rounded-md bg-muted/30">
                          <h4 className="font-semibold">{module.title}</h4>
                          <div className="flex text-sm text-muted-foreground mt-1">
                            <span>{module.lessons} lessons</span>
                            <span className="mx-2">•</span>
                            <span>{module.duration}</span>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="instructor">
                  <Card>
                    <CardHeader>
                      <CardTitle>About The Instructor</CardTitle>
                    </CardHeader>
                    <CardContent className="flex flex-col sm:flex-row items-start gap-6">
                      <Avatar className="h-24 w-24">
                         <img  className="w-full h-full object-cover" alt={course.instructor.name} src="https://images.unsplash.com/photo-1543585959-06f5b68ad5dc" />
                        <AvatarFallback className="text-3xl">{course.instructor.avatar}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-primary">{course.instructor.name}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{course.instructor.title}</p>
                        <p className="text-muted-foreground leading-relaxed mb-4">{course.instructor.bio}</p>
                        <Button variant="outline" size="sm" asChild>
                          <Link to={`/instructors/${course.instructor.id}`}>View Profile</Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="reviews">
                  <Card>
                    <CardHeader><CardTitle>Student Feedback</CardTitle></CardHeader>
                    <CardContent className="space-y-6">
                      {course.studentFeedback.map((feedback, index) => (
                        <div key={index} className="flex items-start gap-4 p-4 border rounded-md bg-muted/30">
                           <Avatar className="h-12 w-12">
                            <img  className="w-full h-full object-cover" alt={feedback.name} src="https://images.unsplash.com/photo-1595819492329-f13804dc377c" />
                            <AvatarFallback>{feedback.avatar}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center mb-1">
                              <h4 className="font-semibold mr-2">{feedback.name}</h4>
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star key={i} size={16} className={` ${i < feedback.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                                ))}
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground">{feedback.comment}</p>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>

          {/* Sidebar */}
          <motion.div 
            initial={{ opacity: 0, x:20 }} 
            animate={{ opacity: 1, x:0 }} 
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-1 space-y-6 sticky top-24"
          >
            <Card className="shadow-xl">
              <CardHeader className="p-0">
                <div className="relative aspect-video">
                   <img  className="w-full h-full object-cover rounded-t-lg" alt={`${course.title} preview thumbnail`} src="https://images.unsplash.com/photo-1694878981885-7647baf0d957" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                     <Button variant="ghost" size="icon" className="h-16 w-16 bg-white/20 hover:bg-white/40 rounded-full">
                      <PlayCircle className="h-10 w-10 text-white" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-baseline gap-2">
                  <h2 className="text-3xl font-bold text-primary">${course.price}</h2>
                  {course.originalPrice && (
                    <span className="text-lg text-muted-foreground line-through">${course.originalPrice}</span>
                  )}
                  {discountPercentage > 0 && (
                     <span className="px-2 py-0.5 bg-red-100 text-red-600 text-xs font-semibold rounded">{discountPercentage}% OFF</span>
                  )}
                </div>
                <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-base">Add to Cart</Button>
                <Button size="lg" variant="outline" className="w-full text-base">Buy Now</Button>
                <p className="text-xs text-muted-foreground text-center">30-Day Money-Back Guarantee</p>
                <div className="space-y-3 pt-4 border-t">
                  <h4 className="font-semibold">This course includes:</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center"><Clock size={16} className="mr-2 text-primary" /> On-demand video</li>
                    <li className="flex items-center"><Download size={16} className="mr-2 text-primary" /> Downloadable resources</li>
                    <li className="flex items-center"><Award size={16} className="mr-2 text-primary" /> Certificate of completion</li>
                    <li className="flex items-center"><Users size={16} className="mr-2 text-primary" /> Full lifetime access</li>
                  </ul>
                </div>
                <div className="flex gap-2 pt-4 border-t">
                  <Button variant="outline" className="flex-1"><Heart size={16} className="mr-2" /> Wishlist</Button>
                  <Button variant="outline" className="flex-1"><Share2 size={16} className="mr-2" /> Share</Button>
                </div>
              </CardContent>
            </Card>
            <Card>
                <CardHeader><CardTitle>Your Progress</CardTitle></CardHeader>
                <CardContent>
                    <Progress value={33} className="w-full mb-2" />
                    <p className="text-sm text-muted-foreground text-center">33% Complete</p>
                </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default CourseDetailsPage;
