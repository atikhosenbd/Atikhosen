
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, User, MessageSquare, Tag, Facebook, Twitter, Linkedin, Send } from 'lucide-react';
import { format } from 'date-fns';

const mockPost = {
  id: '1',
  title: 'Top 5 Skills to Learn in 2025 for Career Growth',
  date: '2025-04-15',
  author: { name: 'Alex Johnson', avatar: 'AJ', bio: 'Alex is a career coach and tech enthusiast with a passion for helping others achieve their professional goals.' },
  category: 'Career',
  tags: ['Skills', 'Development', 'Future', 'Learning', 'Career Advice'],
  image: 'career skills blog detailed image',
  content: `
    <p class="mb-4 text-lg leading-relaxed">The job market is constantly evolving, and staying ahead requires continuous learning and skill development. As we look towards 2025, certain skills are becoming increasingly crucial for career growth and success. In this post, we'll explore the top 5 skills that can significantly boost your professional trajectory.</p>
    
    <h2 class="text-2xl font-semibold my-6">1. Artificial Intelligence (AI) and Machine Learning (ML)</h2>
    <p class="mb-4">AI and ML are no longer just buzzwords; they are transforming industries from healthcare to finance. Understanding the fundamentals of AI/ML, even if you're not a data scientist, can provide a significant advantage. Consider learning about AI ethics, AI-powered tools relevant to your field, or basic Python for data analysis.</p>
    <img class="my-6 rounded-lg shadow-md w-full h-auto object-cover" alt="AI and Machine Learning concept art" src="https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5" />
    
    <h2 class="text-2xl font-semibold my-6">2. Data Literacy and Analysis</h2>
    <p class="mb-4">The ability to understand, interpret, and make decisions based on data is becoming essential in almost every role. This doesn't mean you need to be a statistician, but developing skills in data visualization, basic statistical analysis, and using tools like Excel or Google Sheets for data manipulation is highly valuable.</p>
    
    <h2 class="text-2xl font-semibold my-6">3. Digital Marketing and SEO</h2>
    <p class="mb-4">In an increasingly digital world, understanding how to market products, services, or even yourself online is key. Skills in content creation, social media marketing, search engine optimization (SEO), and email marketing are in high demand across various sectors.</p>
    
    <h2 class="text-2xl font-semibold my-6">4. Cybersecurity Awareness</h2>
    <p class="mb-4">With the rise in cyber threats, basic cybersecurity knowledge is crucial for everyone. Understanding phishing scams, password security, data privacy, and secure online practices protects both you and your organization. For those in tech, specialized cybersecurity skills are, of course, even more valuable.</p>
    <blockquote class="my-6 border-l-4 border-primary pl-4 italic text-muted-foreground">
      "The ability to learn is the most important quality a leader can have." - Sheryl Sandberg
    </blockquote>
    
    <h2 class="text-2xl font-semibold my-6">5. Soft Skills: Communication, Adaptability, and Critical Thinking</h2>
    <p class="mb-4">While technical skills are important, soft skills are what truly set professionals apart. Effective communication (both written and verbal), the ability to adapt to change, problem-solving, and critical thinking are timeless skills that employers consistently seek. These skills are often developed through experience and self-reflection but can also be honed through targeted training.</p>
    
    <p class="mt-8 text-lg">Investing in these skills can open up new career opportunities and help you thrive in the dynamic professional landscape of 2025 and beyond. Online learning platforms like DEVSDEEN offer a plethora of courses to help you get started on your skill development journey.</p>
  `,
  comments: [
    { id: 'c1', user: { name: 'Jane Doe', avatar: 'JD' }, date: '2025-04-16', text: 'Great article! AI/ML is definitely something I need to look into.' },
    { id: 'c2', user: { name: 'John Appleseed', avatar: 'JA' }, date: '2025-04-17', text: 'Very insightful, especially the emphasis on soft skills. Thanks for sharing!' },
  ]
};

const BlogDetailsPage = () => {
  const { postId } = useParams();
  const post = mockPost; 

  if (!post) return <div>Post not found.</div>;

  const breadcrumbs = [
    { label: "Home", link: "/" },
    { label: "Blog", link: "/blog" },
    { label: post.title }
  ];

  return (
    <>
      <PageHeader title={post.title} breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <div className="grid lg:grid-cols-4 gap-10">
          <motion.article 
            className="lg:col-span-3 prose prose-lg max-w-none dark:prose-invert"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <img  className="w-full aspect-video object-cover rounded-xl shadow-lg mb-8" alt={post.title} src="https://images.unsplash.com/photo-1690721606848-ac5bdcde45ea" />
            
            <div className="flex flex-wrap gap-x-6 gap-y-3 items-center text-muted-foreground mb-8 text-sm">
              <div className="flex items-center">
                <Avatar className="h-8 w-8 mr-2">
                  <img  className="w-full h-full object-cover" alt={post.author.name} src="https://images.unsplash.com/photo-1652301173329-31271a0be5c8" />
                  <AvatarFallback>{post.author.avatar}</AvatarFallback>
                </Avatar>
                By <span className="font-medium text-foreground ml-1">{post.author.name}</span>
              </div>
              <div className="flex items-center"><Calendar size={16} className="mr-1.5" /> {format(new Date(post.date), 'MMMM dd, yyyy')}</div>
              <div className="flex items-center"><Tag size={16} className="mr-1.5" /> {post.category}</div>
              <div className="flex items-center"><MessageSquare size={16} className="mr-1.5" /> {post.comments.length} Comments</div>
            </div>

            <div className="text-foreground" dangerouslySetInnerHTML={{ __html: post.content }} />

            <div className="mt-12 pt-8 border-t">
              <h3 className="text-xl font-semibold mb-4 text-foreground">Share this post:</h3>
              <div className="flex space-x-3">
                <Button variant="outline" size="icon"><Facebook className="text-blue-600" /></Button>
                <Button variant="outline" size="icon"><Twitter className="text-sky-500" /></Button>
                <Button variant="outline" size="icon"><Linkedin className="text-blue-700" /></Button>
              </div>
            </div>

            <div className="mt-12 pt-8 border-t">
              <h3 className="text-2xl font-semibold mb-6 text-foreground">{post.comments.length} Comments</h3>
              <div className="space-y-6 mb-8">
                {post.comments.map(comment => (
                  <div key={comment.id} className="flex items-start gap-4">
                    <Avatar>
                      <img  className="w-full h-full object-cover" alt={comment.user.name} src="https://images.unsplash.com/photo-1691398495617-18457fbf826d" />
                      <AvatarFallback>{comment.user.avatar}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 bg-muted/50 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-foreground">{comment.user.name}</span>
                        <span className="text-xs text-muted-foreground">{format(new Date(comment.date), 'MMM dd, yyyy')}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{comment.text}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div>
                <h4 className="text-xl font-semibold mb-4 text-foreground">Leave a Comment</h4>
                <form className="space-y-4">
                  <textarea placeholder="Your comment..." rows={4} className="w-full p-3 border rounded-md focus:ring-primary focus:border-primary bg-background text-foreground"></textarea>
                  <div className="grid md:grid-cols-2 gap-4">
                    <Input type="text" placeholder="Your Name" className="bg-background text-foreground" />
                    <Input type="email" placeholder="Your Email" className="bg-background text-foreground" />
                  </div>
                  <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground"><Send size={16} className="mr-2" /> Post Comment</Button>
                </form>
              </div>
            </div>
          </motion.article>

          <aside className="lg:col-span-1 space-y-8 sticky top-24 self-start">
            <Card>
              <CardHeader><CardTitle>About Author</CardTitle></CardHeader>
              <CardContent className="text-center">
                <Avatar className="w-24 h-24 mx-auto mb-4">
                  <img  className="w-full h-full object-cover" alt={post.author.name} src="https://images.unsplash.com/photo-1688649102455-5e8d7e3fde0f" />
                  <AvatarFallback className="text-3xl">{post.author.avatar}</AvatarFallback>
                </Avatar>
                <h4 className="font-semibold text-lg text-foreground">{post.author.name}</h4>
                <p className="text-sm text-muted-foreground mt-1 mb-3">{post.author.bio}</p>
                <Button variant="outline" size="sm" asChild>
                  <Link to="#">View Profile</Link>
                </Button>
              </CardContent>
            </Card>
             <Card>
              <CardHeader><CardTitle>Tags</CardTitle></CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                {post.tags.map(tag => (
                  <Button key={tag} variant="outline" size="sm" className="text-xs bg-secondary hover:bg-secondary/80">
                    {tag}
                  </Button>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Recent Posts</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[1,2,3].map(i => (
                  <Link key={i} to="#" className="block group">
                    <p className="font-medium group-hover:text-primary text-sm text-foreground">Example Recent Post Title {i}</p>
                    <p className="text-xs text-muted-foreground">{format(new Date(), 'MMM dd, yyyy')}</p>
                  </Link>
                ))}
              </CardContent>
            </Card>
          </aside>
        </div>
      </div>
    </>
  );
};

export default BlogDetailsPage;
