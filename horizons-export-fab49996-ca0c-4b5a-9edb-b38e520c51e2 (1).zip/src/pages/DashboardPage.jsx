
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Users, BookOpen, Calendar, BarChart2, Bell, PlusCircle } from "lucide-react";
import DashboardStatCard from "@/components/dashboard/DashboardStatCard";
import OverviewTab from "@/components/dashboard/tabs/OverviewTab";
import GenericTabContent from "@/components/dashboard/tabs/GenericTabContent";

const initialStats = [
  { title: "Total Students", value: "1,234", change: "+12%", icon: <Users className="h-5 w-5" />, color: "bg-blue-100 text-blue-700" },
  { title: "Active Courses", value: "42", change: "+5%", icon: <BookOpen className="h-5 w-5" />, color: "bg-green-100 text-green-700" },
  { title: "Attendance Rate", value: "92%", change: "+3%", icon: <Calendar className="h-5 w-5" />, color: "bg-purple-100 text-purple-700" },
  { title: "Average Grade", value: "B+", change: "+2%", icon: <BarChart2 className="h-5 w-5" />, color: "bg-amber-100 text-amber-700" },
];

const initialRecentStudents = [
  { id: 1, name: "Emma Wilson", grade: "A", course: "Mathematics", avatar: "EW" },
  { id: 2, name: "James Brown", grade: "B+", course: "Physics", avatar: "JB" },
  { id: 3, name: "Olivia Smith", grade: "A-", course: "Chemistry", avatar: "OS" },
];

const initialUpcomingEvents = [
  { id: 1, title: "End of Term Exams", date: "June 15, 2025", type: "exam" },
  { id: 2, title: "Parent-Teacher Meeting", date: "June 20, 2025", type: "meeting" },
];

const initialRecentMessages = [
  { id: 1, from: "Principal Johnson", subject: "Staff Meeting", time: "2 hours ago", unread: true },
  { id: 2, from: "Mrs. Thompson", subject: "Curriculum Update", time: "Yesterday", unread: false },
];

const DashboardPage = () => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
    const userData = localStorage.getItem("user");
    
    if (!isLoggedIn || !userData) {
      toast({ title: "Authentication required", description: "Please log in to access the dashboard.", variant: "destructive" });
      navigate("/login");
      return;
    }
    
    setUser(JSON.parse(userData));
    setIsLoading(false);
  }, [navigate, toast]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, {user?.name || "User"}! Here's what's happening.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm"> <Bell className="h-4 w-4 mr-2" /> Notifications </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground"> <PlusCircle className="h-4 w-4 mr-2" /> Add Student </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {initialStats.map((stat, index) => (
          <DashboardStatCard key={index} {...stat} delay={index} />
        ))}
      </div>

      <Tabs defaultValue="overview" className="mb-8">
        <TabsList className="mb-6 grid w-full grid-cols-2 md:grid-cols-4 h-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="students">Students</TabsTrigger>
          <TabsTrigger value="courses">Courses</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <OverviewTab recentStudents={initialRecentStudents} upcomingEvents={initialUpcomingEvents} recentMessages={initialRecentMessages} />
        </TabsContent>
        
        <TabsContent value="students">
          <GenericTabContent title="Student Management" description="View and manage all students" searchPlaceholder="Search students..." addActionText="Add Student" />
        </TabsContent>
        
        <TabsContent value="courses">
          <GenericTabContent title="Course Management" description="View and manage all courses" searchPlaceholder="Search courses..." addActionText="Add Course" />
        </TabsContent>
        
        <TabsContent value="reports">
          <GenericTabContent title="Reports & Analytics" description="View detailed reports and analytics" searchPlaceholder="Search reports..." addActionText="New Report" />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DashboardPage;
