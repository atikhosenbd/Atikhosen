
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import BlogCard from '@/components/BlogCard';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, Tag, CalendarDays } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';

const mockBlogPosts = [
  { id: '1', title: 'Top 5 Skills to Learn in 2025 for Career Growth', date: '2025-04-15', author: 'Alex Johnson', excerpt: 'Discover the most in-demand skills...', comments: 12, category: 'Career', tags: ['Skills', 'Development', 'Future'], image: 'career skills blog image' },
  { id: '2', title: 'The Future of Online Education: Trends and Predictions', date: '2025-04-10', author: 'Maria Garcia', excerpt: 'Explore how technology is shaping the future of education...', comments: 8, category: 'Education', tags: ['Online Learning', 'Technology', 'EdTech'], image: 'online education trends blog image' },
  { id: '3', title: 'Effective Time Management Strategies for Online Students', date: '2025-04-05', author: 'David Kim', excerpt: 'Learn practical tips and techniques to manage your time...', comments: 22, category: 'Productivity', tags: ['Time Management', 'Study Tips'], image: 'time management blog image' },
  { id: '4', title: 'Understanding Blockchain Technology: A Beginner\'s Guide', date: '2025-03-28', author: 'Sarah Lee', excerpt: 'Demystifying blockchain technology and its potential applications.', comments: 15, category: 'Technology', tags: ['Blockchain', 'Crypto', 'Web3'], image: 'blockchain blog image' },
  { id: '5', title: 'The Importance of Soft Skills in Today\'s Workplace', date: '2025-03-20', author: 'James Brown', excerpt: 'Why communication, teamwork, and adaptability are crucial for success.', comments: 10, category: 'Career', tags: ['Soft Skills', 'Professional Development'], image: 'soft skills blog image' },
  { id: '6', title: 'A Deep Dive into Artificial Intelligence and Machine Learning', date: '2025-03-12', author: 'Linda Chen', excerpt: 'Exploring the concepts, applications, and ethics of AI/ML.', comments: 18, category: 'Technology', tags: ['AI', 'Machine Learning', 'Ethics'], image: 'ai ml blog image' },
];

const allCategories = ['All', 'Career', 'Education', 'Productivity', 'Technology'];
const popularTags = ['Skills', 'Online Learning', 'EdTech', 'Time Management', 'AI', 'Development'];

const BlogPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortBy, setSortBy] = useState("newest");

  const breadcrumbs = [{ label: "Home", link: "/" }, { label: "Blog" }];

  const filteredPosts = mockBlogPosts
    .filter(post => 
      (post.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
       post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (selectedCategory === "All" || post.category === selectedCategory)
    )
    .sort((a, b) => {
      if (sortBy === "newest") return new Date(b.date) - new Date(a.date);
      if (sortBy === "oldest") return new Date(a.date) - new Date(b.date);
      if (sortBy === "popular") return b.comments - a.comments; // Simple popularity by comments
      return 0;
    });

  return (
    <>
      <PageHeader title="Our Blog" breadcrumbs={breadcrumbs} />
      <div className="container section-padding">
        <div className="grid lg:grid-cols-4 gap-10">
          {/* Blog Posts */}
          <div className="lg:col-span-3">
            {filteredPosts.length === 0 ? (
              <div className="text-center py-12">
                <Search className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-2xl font-medium mb-2">No Posts Found</h3>
                <p className="text-muted-foreground">Try a different search or category.</p>
              </div>
            ) : (
              <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 gap-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ staggerChildren: 0.1 }}
              >
                {filteredPosts.map((post, index) => (
                  <motion.div 
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.05 }}
                  >
                    <BlogCard post={post} />
                  </motion.div>
                ))}
              </motion.div>
            )}
            {filteredPosts.length > 0 && (
              <div className="mt-12 flex justify-center">
                <Button size="lg" variant="outline">Load More Posts</Button>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-1 space-y-8 sticky top-24 self-start">
            <Card>
              <CardHeader><CardTitle>Search Blog</CardTitle></CardHeader>
              <CardContent>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    type="search" 
                    placeholder="Search posts..." 
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Categories</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {allCategories.map(category => (
                    <li key={category}>
                      <Button 
                        variant={selectedCategory === category ? "default" : "ghost"}
                        className="w-full justify-start"
                        onClick={() => setSelectedCategory(category)}
                      >
                        {category}
                      </Button>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader><CardTitle>Sort By</CardTitle></CardHeader>
              <CardContent>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Sort posts by..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="popular">Most Popular</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Popular Tags</CardTitle></CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                {popularTags.map(tag => (
                  <Button key={tag} variant="outline" size="sm" className="text-xs">
                    <Tag size={12} className="mr-1.5" /> {tag}
                  </Button>
                ))}
              </CardContent>
            </Card>
          </aside>
        </div>
      </div>
    </>
  );
};

export default BlogPage;
