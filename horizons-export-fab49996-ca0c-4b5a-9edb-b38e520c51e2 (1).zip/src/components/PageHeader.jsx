
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

const PageHeader = ({ title, breadcrumbs }) => {
  return (
    <div className="bg-muted/50 py-12 md:py-16">
      <div className="container text-center">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">{title}</h1>
        {breadcrumbs && breadcrumbs.length > 0 && (
          <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
            {breadcrumbs.map((crumb, index) => (
              <React.Fragment key={index}>
                {index > 0 && <ChevronRight size={16} />}
                {crumb.link ? (
                  <Link to={crumb.link} className="hover:text-primary">
                    {crumb.label}
                  </Link>
                ) : (
                  <span>{crumb.label}</span>
                )}
              </React.Fragment>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PageHeader;
