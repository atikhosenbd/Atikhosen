
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, User, MessageSquare } from 'lucide-react';
import { format } from 'date-fns';

const BlogCard = ({ post }) => {
  return (
    <Card className="overflow-hidden h-full flex flex-col hover:shadow-xl transition-shadow duration-300">
      <Link to={`/blog/${post.id}`} className="block">
        <img 
          className="w-full h-56 object-cover"
          alt={post.title}
         src="https://images.unsplash.com/photo-1504983875-d3b163aba9e6" />
      </Link>
      <CardHeader>
        <Link to={`/blog/${post.id}`}>
          <CardTitle className="text-xl hover:text-primary transition-colors">{post.title}</CardTitle>
        </Link>
        <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-2">
          <div className="flex items-center">
            <Calendar size={14} className="mr-1.5" />
            {format(new Date(post.date), 'MMMM dd, yyyy')}
          </div>
          <div className="flex items-center">
            <User size={14} className="mr-1.5" />
            {post.author}
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-muted-foreground line-clamp-3">{post.excerpt}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <Link to={`/blog/${post.id}`}>
          <Button variant="outline" size="sm">Read More</Button>
        </Link>
        <div className="flex items-center text-sm text-muted-foreground">
          <MessageSquare size={14} className="mr-1.5" />
          {post.comments} Comments
        </div>
      </CardFooter>
    </Card>
  );
};

export default BlogCard;
