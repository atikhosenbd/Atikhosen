
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, BookOpen, Users } from 'lucide-react';

const InstructorCard = ({ instructor }) => {
  return (
    <Card className="text-center hover:shadow-xl transition-shadow duration-300">
      <CardContent className="p-6">
        <div className="relative w-32 h-32 mx-auto mb-4">
          <img 
            className="w-full h-full rounded-full object-cover border-4 border-primary/20"
            alt={instructor.name}
           src="https://images.unsplash.com/photo-1586732711591-12c04655338f" />
          {instructor.isVerified && (
            <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground p-1.5 rounded-full transform translate-x-1/4 translate-y-1/4">
              <Star size={12} fill="currentColor" />
            </div>
          )}
        </div>
        <h3 className="text-xl font-semibold mb-1">{instructor.name}</h3>
        <p className="text-primary text-sm mb-3">{instructor.title}</p>
        <div className="flex justify-center space-x-4 text-sm text-muted-foreground mb-4">
          <div className="flex items-center">
            <BookOpen size={14} className="mr-1" /> {instructor.courses} Courses
          </div>
          <div className="flex items-center">
            <Users size={14} className="mr-1" /> {instructor.students} Students
          </div>
        </div>
        <Link to={`/instructors/${instructor.id}`}>
          <Button variant="outline" size="sm">View Profile</Button>
        </Link>
      </CardContent>
    </Card>
  );
};

export default InstructorCard;
