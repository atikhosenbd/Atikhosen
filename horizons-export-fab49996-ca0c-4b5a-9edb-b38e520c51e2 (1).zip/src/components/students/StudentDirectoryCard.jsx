
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Mail, Phone, BookOpen } from "lucide-react";

const StudentDirectoryCard = ({ student }) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 h-full flex flex-col">
      <CardContent className="p-5 flex flex-col items-center text-center flex-grow">
        <Avatar className="h-24 w-24 mb-4 border-2 border-primary/20">
          <AvatarImage src={`https://i.pravatar.cc/150?u=${student.id}`} alt={student.name} />
          <AvatarFallback className="text-2xl">{student.avatar}</AvatarFallback>
        </Avatar>
        <h3 className="font-semibold text-lg text-foreground">{student.name}</h3>
        <p className="text-sm text-primary mb-1">{student.grade}</p>
        <div className="mt-1 px-3 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 mb-3">
          {student.attendance} Attendance
        </div>
        
        <div className="space-y-2 text-left text-sm w-full mb-4 flex-grow">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Mail size={14} /> <span className="truncate">{student.email}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Phone size={14} /> <span>{student.phone}</span>
          </div>
          <div className="flex items-start gap-2 text-muted-foreground">
            <BookOpen size={14} className="mt-0.5 shrink-0" />
            <span className="truncate" title={student.courses.join(', ')}>
              {student.courses.length} Course{student.courses.length > 1 ? 's' : ''}
            </span>
          </div>
        </div>
        
        <div className="mt-auto w-full flex gap-2">
          <Button variant="outline" size="sm" className="flex-1 text-xs">Profile</Button>
          <Button variant="ghost" size="sm" className="flex-1 text-xs">Edit</Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default StudentDirectoryCard;
