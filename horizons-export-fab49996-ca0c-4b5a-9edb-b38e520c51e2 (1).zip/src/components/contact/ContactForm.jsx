
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { Send } from "lucide-react";

const ContactForm = () => {
  const [formData, setFormData] = useState({ name: "", email: "", phone: "", subject: "", message: "", inquiryType: "general" });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value) => {
    setFormData((prev) => ({ ...prev, inquiryType: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      toast({ title: "Message sent!", description: "We'll get back to you soon.", variant: "default" });
      setFormData({ name: "", email: "", phone: "", subject: "", message: "", inquiryType: "general" });
      setIsLoading(false);
    }, 1500);
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl">Send Us a Message</CardTitle>
        <CardDescription>Fill out the form, and we'll respond as soon as possible.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5"><Label htmlFor="name">Full Name</Label><Input id="name" name="name" value={formData.name} onChange={handleChange} required disabled={isLoading} /></div>
            <div className="space-y-1.5"><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required disabled={isLoading} /></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5"><Label htmlFor="phone">Phone (Optional)</Label><Input id="phone" name="phone" value={formData.phone} onChange={handleChange} disabled={isLoading} /></div>
            <div className="space-y-1.5">
              <Label htmlFor="inquiryType">Inquiry Type</Label>
              <Select value={formData.inquiryType} onValueChange={handleSelectChange} disabled={isLoading}>
                <SelectTrigger id="inquiryType"><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General Inquiry</SelectItem><SelectItem value="sales">Sales</SelectItem>
                  <SelectItem value="support">Support</SelectItem><SelectItem value="demo">Demo Request</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5"><Label htmlFor="subject">Subject</Label><Input id="subject" name="subject" value={formData.subject} onChange={handleChange} required disabled={isLoading} /></div>
          <div className="space-y-1.5">
            <Label htmlFor="message">Message</Label>
            <textarea id="message" name="message" rows={5} className="w-full min-h-[100px] rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50" value={formData.message} onChange={handleChange} required disabled={isLoading}></textarea>
          </div>
          <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled={isLoading}>
            {isLoading ? "Sending..." : <><Send size={16} className="mr-2" /> Send Message</>}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default ContactForm;
