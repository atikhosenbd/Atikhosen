
import React from 'react';

const LocationMap = () => (
  <div className="rounded-xl overflow-hidden shadow-lg h-full min-h-[300px] lg:min-h-full">
    <iframe
      title="DEVSDEEN Office Location"
      src="https://www.openstreetmap.org/export/embed.html?bbox=-74.01042938232423%2C40.70513108480546%2C-73.98262023925783%2C40.71941793907841&amp;layer=mapnik&amp;marker=40.71227451194181%2C-73.99652481079102"
      width="100%"
      height="100%"
      style={{ border: 0 }}
      allowFullScreen=""
      loading="lazy"
      referrerPolicy="no-referrer-when-downgrade"
    ></iframe>
  </div>
);

export default LocationMap;
