
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

const ContactInfoItem = ({ icon, title, details }) => (
  <Card className="h-full hover:shadow-lg transition-shadow">
    <CardContent className="p-6">
      <div className="flex flex-col items-center text-center">
        <div className="p-4 rounded-full bg-primary/10 text-primary mb-4 inline-block">
          {React.cloneElement(icon, { size: 24 })}
        </div>
        <h3 className="font-semibold text-lg mb-2 text-foreground">{title}</h3>
        <div className="space-y-1">
          {details.map((detail, i) => (
            <p key={i} className="text-muted-foreground text-sm">{detail}</p>
          ))}
        </div>
      </div>
    </CardContent>
  </Card>
);

export default ContactInfoItem;
