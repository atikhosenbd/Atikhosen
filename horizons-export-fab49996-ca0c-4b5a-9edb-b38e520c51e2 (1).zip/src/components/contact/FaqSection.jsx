
import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"; 

const faqs = [
  { q: "What types of courses does DEVSDEEN offer?", a: "DEVSDEEN offers a wide range of courses across various disciplines including technology, business, arts, science, and personal development. All courses are taught by industry experts." },
  { q: "Can I access courses on mobile devices?", a: "Yes, the DEVSDEEN platform is fully responsive, allowing you to access your courses and learning materials on any device, including desktops, tablets, and smartphones." },
  { q: "Are there any prerequisites for enrolling in courses?", a: "Most beginner-level courses do not have prerequisites. Specific requirements for advanced courses are listed on the respective course detail pages." },
  { q: "Do I get a certificate upon course completion?", a: "Yes, upon successful completion of a course, you will receive a digital certificate from DEVSDEEN, which you can share on your professional profiles." },
  { q: "What is the refund policy?", a: "We offer a 30-day money-back guarantee on most courses. Please refer to our refund policy page for detailed information." },
];

const FaqSection = () => (
  <div>
    <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8 text-center lg:text-left">Frequently Asked Questions</h2>
    <Accordion type="single" collapsible className="w-full">
      {faqs.map((faq, index) => (
        <AccordionItem value={`item-${index}`} key={index}>
          <AccordionTrigger className="text-left hover:no-underline text-base">{faq.q}</AccordionTrigger>
          <AccordionContent className="text-muted-foreground text-sm leading-relaxed">{faq.a}</AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  </div>
);

export default FaqSection;
