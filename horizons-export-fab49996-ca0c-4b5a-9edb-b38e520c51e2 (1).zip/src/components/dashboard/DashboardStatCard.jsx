
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

const DashboardStatCard = ({ title, value, change, icon, color, delay }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: delay * 0.1 }}
    >
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
              <div className="flex items-end gap-2">
                <h3 className="text-2xl font-bold">{value}</h3>
                {change && <span className="text-xs font-medium text-green-600">{change}</span>}
              </div>
            </div>
            {icon && (
              <div className={`p-2.5 rounded-full ${color || 'bg-primary/10 text-primary'}`}>
                {icon}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default DashboardStatCard;
