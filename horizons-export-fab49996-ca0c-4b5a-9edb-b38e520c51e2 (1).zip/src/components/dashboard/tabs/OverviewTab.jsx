
import React from 'react';
import DashboardSectionCard from '@/components/dashboard/DashboardSectionCard';
import RecentStudentItem from '@/components/dashboard/overview/RecentStudentItem';
import UpcomingEventItem from '@/components/dashboard/overview/UpcomingEventItem';
import RecentMessageItem from '@/components/dashboard/overview/RecentMessageItem';
import { Button } from "@/components/ui/button";
import { Filter } from "lucide-react";

const OverviewTab = ({ recentStudents, upcomingEvents, recentMessages }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <DashboardSectionCard
        title="Recent Students"
        description="Latest student activities and performance"
        className="lg:col-span-2"
        headerActions={
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="xs"> <Filter className="h-3 w-3 mr-1" /> Filter </Button>
            <Button variant="outline" size="xs">View All</Button>
          </div>
        }
      >
        <div className="space-y-3 -mx-3 -my-2">
          {recentStudents.map((student) => (
            <RecentStudentItem key={student.id} student={student} />
          ))}
        </div>
      </DashboardSectionCard>
      
      <div className="space-y-6">
        <DashboardSectionCard title="Upcoming Events" description="Schedule for the next few weeks">
          <div className="space-y-3 -mx-1 -my-1">
            {upcomingEvents.map((event) => (
              <UpcomingEventItem key={event.id} event={event} />
            ))}
          </div>
        </DashboardSectionCard>
        
        <DashboardSectionCard title="Recent Messages" description="Latest communications">
          <div className="space-y-3 -mx-1 -my-1">
            {recentMessages.map((message) => (
              <RecentMessageItem key={message.id} message={message} />
            ))}
          </div>
        </DashboardSectionCard>
      </div>
    </div>
  );
};

export default OverviewTab;
