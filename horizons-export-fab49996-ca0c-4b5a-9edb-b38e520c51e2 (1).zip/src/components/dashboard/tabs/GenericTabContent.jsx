
import React from 'react';
import DashboardSectionCard from '@/components/dashboard/DashboardSectionCard';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, PlusCircle } from "lucide-react";

const GenericTabContent = ({ title, description, searchPlaceholder, addActionText }) => {
  return (
    <DashboardSectionCard
      title={title}
      description={description}
      headerActions={
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder={searchPlaceholder} className="pl-8 w-full sm:w-[200px] lg:w-[250px] h-9 text-sm" />
          </div>
          <Button size="sm"> <PlusCircle className="h-4 w-4 mr-2" /> {addActionText} </Button>
        </div>
      }
    >
      <p className="text-center py-12 text-muted-foreground">
        {title} interface will be displayed here.
      </p>
    </DashboardSectionCard>
  );
};

export default GenericTabContent;
