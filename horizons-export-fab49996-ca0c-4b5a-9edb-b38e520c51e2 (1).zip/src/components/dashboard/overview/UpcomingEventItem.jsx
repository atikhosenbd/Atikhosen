
import React from 'react';
import { Users, FileText, Calendar as CalendarIcon } from "lucide-react";

const UpcomingEventItem = ({ event }) => {
  const getEventStyle = (type) => {
    switch (type) {
      case 'exam': return { icon: <FileText className="h-4 w-4" />, color: 'bg-red-100 text-red-700' };
      case 'meeting': return { icon: <Users className="h-4 w-4" />, color: 'bg-blue-100 text-blue-700' };
      case 'event': return { icon: <CalendarIcon className="h-4 w-4" />, color: 'bg-purple-100 text-purple-700' };
      default: return { icon: <CalendarIcon className="h-4 w-4" />, color: 'bg-green-100 text-green-700' };
    }
  };
  const { icon, color } = getEventStyle(event.type);

  return (
    <div className="flex items-start gap-3 p-1">
      <div className={`p-2 rounded-full mt-0.5 ${color}`}>
        {icon}
      </div>
      <div>
        <p className="font-medium text-sm">{event.title}</p>
        <p className="text-xs text-muted-foreground">{event.date}</p>
      </div>
    </div>
  );
};
export default UpcomingEventItem;
