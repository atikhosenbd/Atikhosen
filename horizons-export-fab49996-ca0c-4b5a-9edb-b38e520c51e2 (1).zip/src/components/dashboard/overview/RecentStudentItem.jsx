
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

const RecentStudentItem = ({ student }) => {
  const getGradeColor = (grade) => {
    if (grade.startsWith('A')) return 'bg-green-100 text-green-800';
    if (grade.startsWith('B')) return 'bg-blue-100 text-blue-800';
    if (grade.startsWith('C')) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div className="flex items-center justify-between p-3 hover:bg-muted/50 rounded-md transition-colors">
      <div className="flex items-center gap-3">
        <Avatar className="h-10 w-10">
          <AvatarImage src={`https://i.pravatar.cc/150?u=${student.id}`} alt={student.name} />
          <AvatarFallback>{student.avatar}</AvatarFallback>
        </Avatar>
        <div>
          <p className="font-medium text-sm">{student.name}</p>
          <p className="text-xs text-muted-foreground">{student.course}</p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className={`px-2.5 py-1 rounded-full text-xs font-semibold ${getGradeColor(student.grade)}`}>
          {student.grade}
        </div>
        <Button variant="ghost" size="sm" className="text-xs">View</Button>
      </div>
    </div>
  );
};
export default RecentStudentItem;
