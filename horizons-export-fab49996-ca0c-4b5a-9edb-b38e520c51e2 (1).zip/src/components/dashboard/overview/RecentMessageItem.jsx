
import React from 'react';
import { MessageSquare } from "lucide-react";

const RecentMessageItem = ({ message }) => {
  return (
    <div className="flex items-start gap-3 p-1">
      <div className={`p-2 rounded-full mt-0.5 ${message.unread ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
        <MessageSquare className="h-4 w-4" />
      </div>
      <div>
        <div className="flex items-center gap-2">
          <p className="font-medium text-sm">{message.from}</p>
          {message.unread && <span className="h-2 w-2 rounded-full bg-primary"></span>}
        </div>
        <p className="text-xs">{message.subject}</p>
        <p className="text-xs text-muted-foreground">{message.time}</p>
      </div>
    </div>
  );
};
export default RecentMessageItem;
