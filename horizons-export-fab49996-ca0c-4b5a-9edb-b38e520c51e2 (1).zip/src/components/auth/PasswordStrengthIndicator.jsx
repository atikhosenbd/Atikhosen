
import React from 'react';
import { CheckCircle2 } from 'lucide-react';

export const getPasswordStrength = (password) => {
  if (!password) return { strength: 0, text: "", criteria: [] };
  
  let strength = 0;
  const criteria = [
    { text: "At least 8 characters", met: password.length >= 8 },
    { text: "At least one uppercase letter", met: /[A-Z]/.test(password) },
    { text: "At least one lowercase letter", met: /[a-z]/.test(password) },
    { text: "At least one number", met: /[0-9]/.test(password) },
    // { text: "At least one special character", met: /[^A-Za-z0-9]/.test(password) }, // Optional
  ];

  criteria.forEach(criterion => {
    if (criterion.met) strength++;
  });
  
  const strengthTextMap = ["Very Weak", "Weak", "Fair", "Good", "Strong"];
  const strengthText = strength > 0 ? strengthTextMap[Math.min(strength, strengthTextMap.length - 1)] : "";
  
  return { strength, text: strengthText, criteria };
};


const PasswordStrengthIndicator = ({ password }) => {
  const { strength, text, criteria } = getPasswordStrength(password);

  if (!password) return null;

  const strengthColors = [
    "bg-red-500",      // Very Weak (1 point)
    "bg-orange-500",   // Weak (2 points)
    "bg-yellow-500",   // Fair (3 points)
    "bg-lime-500",     // Good (4 points)
    "bg-green-500",    // Strong (5 points)
  ];

  const strengthWidths = ["w-1/5", "w-2/5", "w-3/5", "w-4/5", "w-full"];

  return (
    <div className="mt-2 space-y-2">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs text-muted-foreground">Password strength:</span>
        <span className={`text-xs font-medium ${
          strength === 1 ? "text-red-500" :
          strength === 2 ? "text-orange-500" :
          strength === 3 ? "text-yellow-500" :
          strength === 4 ? "text-lime-500" :
          strength >= 5 ? "text-green-500" : "text-muted-foreground"
        }`}>
          {text || "Too short"}
        </span>
      </div>
      <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
        <div 
          className={`h-full transition-all duration-300 ease-in-out ${strength > 0 ? strengthColors[Math.min(strength -1, strengthColors.length -1)] : ""} ${strength > 0 ? strengthWidths[Math.min(strength - 1, strengthWidths.length -1)] : "w-0"}`}
        ></div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 mt-2">
        {criteria.map((criterion, index) => (
          <div key={index} className="flex items-center text-xs">
            <CheckCircle2 className={`h-3.5 w-3.5 mr-1.5 shrink-0 ${criterion.met ? "text-green-500" : "text-muted-foreground/50"}`} />
            <span className={criterion.met ? "text-green-600" : "text-muted-foreground/70"}>
              {criterion.text}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PasswordStrengthIndicator;
