
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const AuthCardWrapper = ({ children, title, description, footerText, footerLink, footerLinkText }) => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/fab49996-ca0c-4b5a-9edb-b38e520c51e2/741610e3dbce7bc5201f7d201b01c43b.png";
  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="w-full max-w-md">
        <Card>
          <CardHeader className="space-y-1">
            <Link to="/" className="flex justify-center mb-4">
              <img src={logoUrl} alt="DEVSDEEN Logo" className="h-10" />
            </Link>
            <CardTitle className="text-2xl text-center">{title}</CardTitle>
            {description && (
              <CardDescription className="text-center">
                {description}
              </CardDescription>
            )}
          </CardHeader>
          <CardContent>
            {children}
          </CardContent>
          {(footerText || footerLinkText) && (
            <CardFooter className="flex flex-col space-y-4">
              {footerText && footerLink && footerLinkText && (
                <div className="text-center text-sm">
                  {footerText}{" "}
                  <Link to={footerLink} className="text-primary hover:underline font-medium">
                    {footerLinkText}
                  </Link>
                </div>
              )}
               <div className="text-center text-xs text-muted-foreground">
                By continuing, you agree to DEVSDEEN's{" "}
                <Link to="/terms" className="underline hover:text-primary">
                  Terms of Service
                </Link>{" "}
                and{" "}
                <Link to="/privacy" className="underline hover:text-primary">
                  Privacy Policy
                </Link>
                .
              </div>
            </CardFooter>
          )}
        </Card>
      </div>
    </div>
  );
};

export default AuthCardWrapper;
