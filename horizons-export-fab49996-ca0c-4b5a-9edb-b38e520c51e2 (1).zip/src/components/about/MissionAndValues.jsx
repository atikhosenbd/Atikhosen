
import React from 'react';
import { motion } from 'framer-motion';
import ValueCard from './ValueCard';
import { Users, BookOpen, Zap, Target, ShieldCheck, Lightbulb } from 'lucide-react';

const values = [
  { icon: <Zap className="h-6 w-6" />, title: "Empowerment", description: "We empower individuals by providing accessible tools and knowledge to achieve their full potential." },
  { icon: <Lightbulb className="h-6 w-6" />, title: "Innovation", description: "We constantly seek innovative solutions to enhance the learning experience and adapt to future educational needs." },
  { icon: <Users className="h-6 w-6" />, title: "Community", description: "We foster a supportive and collaborative learning community for students, instructors, and partners." },
];

const MissionAndValues = () => (
  <section className="section-padding bg-muted/30">
    <div className="container">
      <motion.div
        className="text-center max-w-3xl mx-auto mb-16"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-3xl font-bold mb-4 text-foreground">Our Mission & Core Values</h2>
        <p className="text-lg text-muted-foreground">
          Our mission is to make quality education accessible to all, driven by values that shape our culture and guide our decisions.
        </p>
      </motion.div>
      <motion.div
        className="grid md:grid-cols-3 gap-8"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{ visible: { transition: { staggerChildren: 0.1 } } }}
      >
        {values.map((value, index) => (
          <motion.div key={index} variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }}>
            <ValueCard {...value} />
          </motion.div>
        ))}
      </motion.div>
    </div>
  </section>
);

export default MissionAndValues;
