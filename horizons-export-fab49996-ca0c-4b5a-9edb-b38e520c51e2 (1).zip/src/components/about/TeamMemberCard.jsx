
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Linkedin, Twitter } from 'lucide-react';

const TeamMemberCard = ({ name, role, bio, imageSrc }) => (
  <Card className="h-full overflow-hidden text-center hover:shadow-xl transition-shadow">
    <div className="aspect-[4/5] w-full overflow-hidden bg-muted">
      <img  className="w-full h-full object-cover object-top" alt={name} src={imageSrc} />
    </div>
    <CardContent className="p-6">
      <h3 className="font-semibold text-lg text-foreground">{name}</h3>
      <p className="text-sm text-primary mb-2">{role}</p>
      <p className="text-xs text-muted-foreground mb-3 line-clamp-3">{bio}</p>
      <div className="flex justify-center space-x-2">
        <a href="#" className="text-muted-foreground hover:text-primary"><Linkedin size={18} /></a>
        <a href="#" className="text-muted-foreground hover:text-primary"><Twitter size={18} /></a>
      </div>
    </CardContent>
  </Card>
);

export default TeamMemberCard;
