
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

const ValueCard = ({ icon, title, description }) => (
  <Card className="h-full hover:shadow-lg transition-shadow">
    <CardContent className="p-6">
      <div className="mb-4 p-3 rounded-full bg-primary/10 text-primary inline-block">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3 text-foreground">{title}</h3>
      <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
    </CardContent>
  </Card>
);

export default ValueCard;
