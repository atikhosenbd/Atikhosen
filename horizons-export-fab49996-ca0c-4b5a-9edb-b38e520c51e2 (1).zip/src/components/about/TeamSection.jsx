
import React from 'react';
import { motion } from 'framer-motion';
import TeamMemberCard from './TeamMemberCard';

const teamMembers = [
  { name: "Dr. Evelyn Reed", role: "Founder & CEO", bio: "Passionate about leveraging technology to make education accessible to everyone, everywhere.", imageSrc: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2" },
  { name: "Marcus Chen", role: "Chief Technology Officer", bio: "Expert in building scalable learning platforms and fostering innovation in EdTech.", imageSrc: "https://images.unsplash.com/photo-1557862921-37829c7ef0f1" },
  { name: "Aisha Khan", role: "Head of Curriculum Development", bio: "Dedicated to creating engaging and effective course content with renowned educators.", imageSrc: "https://images.unsplash.com/photo-1534528741775-53994a69daeb" },
  { name: "David Miller", role: "Director of Student Success", bio: "Committed to ensuring every learner achieves their goals and has a positive experience.", imageSrc: "https://images.unsplash.com/photo-1560250097-0b93528c311a" },
];

const TeamSection = () => (
  <section className="section-padding">
    <div className="container">
      <motion.div
        className="text-center max-w-3xl mx-auto mb-16"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-3xl font-bold mb-4 text-foreground">Meet Our Leadership Team</h2>
        <p className="text-lg text-muted-foreground">
          The passionate experts behind DEVSDEEN, dedicated to shaping the future of online learning.
        </p>
      </motion.div>
      <motion.div
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{ visible: { transition: { staggerChildren: 0.1 } } }}
      >
        {teamMembers.map((member, index) => (
          <motion.div key={index} variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }}>
            <TeamMemberCard {...member} />
          </motion.div>
        ))}
      </motion.div>
    </div>
  </section>
);

export default TeamSection;
