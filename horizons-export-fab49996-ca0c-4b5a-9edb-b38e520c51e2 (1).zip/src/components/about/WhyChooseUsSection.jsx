
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

const features = [
  { title: "Expert-Led Courses", description: "Learn from industry leaders and renowned academics with practical, up-to-date knowledge." },
  { title: "Flexible Learning", description: "Study at your own pace, anytime, anywhere, with lifetime access to course materials." },
  { title: "Interactive Community", description: "Connect with fellow learners, share insights, and collaborate on projects in our vibrant community." },
  { title: "Recognized Certifications", description: "Earn valuable certifications upon course completion to boost your resume and career prospects." },
  { title: "Dedicated Support", description: "Our team is always here to help you with any questions or technical issues you may encounter." },
  { title: "Affordable Pricing", description: "Access high-quality education without breaking the bank. We offer various plans and financial aid." },
];

const WhyChooseUsSection = () => (
  <section className="section-padding bg-muted/30">
    <div className="container">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="order-2 lg:order-1"
        >
          <h2 className="text-3xl font-bold mb-6 text-foreground">Why Choose DEVSDEEN?</h2>
          <p className="text-muted-foreground text-lg mb-6">
            We are committed to providing an unparalleled learning experience. Here’s what sets us apart:
          </p>
          <div className="space-y-4">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary mt-0.5 shrink-0" />
                <div>
                  <h3 className="font-semibold text-md text-foreground">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
        <motion.div
          className="order-1 lg:order-2"
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative rounded-xl overflow-hidden shadow-2xl aspect-[4/3]">
            <img  className="w-full h-full object-cover" alt="Students happily learning online" src="https://images.unsplash.com/photo-1531482615713-2afd69097998" />
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default WhyChooseUsSection;
