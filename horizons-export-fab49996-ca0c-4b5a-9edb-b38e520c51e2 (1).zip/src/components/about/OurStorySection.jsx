
import React from 'react';
import { motion } from 'framer-motion';
import { Award } from 'lucide-react';

const OurStorySection = () => (
  <section className="section-padding">
    <div className="container">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-bold mb-6 text-foreground">Our Story: The Journey of DEVSDEEN</h2>
          <div className="space-y-4 text-muted-foreground text-base leading-relaxed">
            <p>Founded in 2020, DEVSDEEN emerged from a collective passion for revolutionizing education. We saw the need for a platform that not only imparts knowledge but also fosters a community of lifelong learners.</p>
            <p>Our journey began with a small team of educators and tech innovators dedicated to creating an accessible, engaging, and effective online learning experience. We believe education should be a right, not a privilege.</p>
            <p>Today, DEVSDEEN proudly serves thousands of students and professionals globally, offering a diverse range of courses designed to meet the evolving demands of the modern world. Our commitment to quality and innovation continues to drive us forward.</p>
          </div>
        </motion.div>
        <motion.div
          className="relative"
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative rounded-xl overflow-hidden shadow-2xl aspect-[4/3]">
            <img  className="w-full h-full object-cover" alt="Team working together in an office environment" src="https://images.unsplash.com/photo-1522071820081-009f0129c71c" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
          </div>
          <div className="absolute -bottom-6 -left-6 bg-background p-4 rounded-lg shadow-xl border border-primary/20">
            <div className="flex items-center gap-2 text-primary font-medium">
              <Award className="h-5 w-5" />
              <span>Innovator in Education Award 2024</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default OurStorySection;
