
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const AboutHero = () => (
  <section className="py-20 md:py-28 bg-muted/30">
    <div className="container">
      <motion.div
        className="max-w-3xl mx-auto text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl md:text-5xl font-extrabold mb-6 text-foreground">About DEVSDEEN</h1>
        <p className="text-xl text-muted-foreground mb-8">
          We're on a mission to transform educational administration and enhance learning outcomes through innovative technology solutions.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/contact">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto">
              Contact Us <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
          <Link to="/courses">
            <Button size="lg" variant="outline" className="w-full sm:w-auto">
              Explore Courses
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  </section>
);

export default AboutHero;
