
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Clock, Users, BarChart, Star } from 'lucide-react';

const CourseCard = ({ course }) => {
  return (
    <Card className="overflow-hidden h-full flex flex-col hover:shadow-xl transition-shadow duration-300">
      <div className="relative">
        <img 
          className="w-full h-48 object-cover"
          alt={course.title}
         src="https://images.unsplash.com/photo-1677696795233-5ef097695f12" />
        <div className="absolute top-3 right-3 bg-primary text-primary-foreground px-2 py-1 text-xs font-semibold rounded">
          {course.category}
        </div>
      </div>
      <CardHeader>
        <CardTitle className="text-lg leading-tight mb-1">{course.title}</CardTitle>
        <div className="flex items-center text-sm text-muted-foreground">
          <img 
            className="w-6 h-6 rounded-full mr-2 object-cover"
            alt={course.instructor.name}
           src="https://images.unsplash.com/photo-1574706363447-458d08016961" />
          <span>{course.instructor.name}</span>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-muted-foreground mb-4 line-clamp-3">{course.description}</p>
        <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
          <div className="flex items-center">
            <Clock size={14} className="mr-1.5 text-primary" /> {course.duration}
          </div>
          <div className="flex items-center">
            <Users size={14} className="mr-1.5 text-primary" /> {course.students} Students
          </div>
          <div className="flex items-center">
            <BarChart size={14} className="mr-1.5 text-primary" /> {course.level}
          </div>
          <div className="flex items-center">
            <Star size={14} className="mr-1.5 text-yellow-400 fill-yellow-400" /> {course.rating} ({course.reviews} reviews)
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Link to={`/courses/${course.id}`} className="w-full">
          <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">View Course</Button>
        </Link>
      </CardFooter>
    </Card>
  );
};

export default CourseCard;
