
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import BlogCard from '@/components/BlogCard'; 
import { ArrowRight } from 'lucide-react';

const mockBlogPosts = [
  {
    id: '1',
    title: 'Top 5 Skills to Learn in 2025 for Career Growth',
    date: '2025-04-15',
    author: 'Alex Johnson',
    excerpt: 'Discover the most in-demand skills in the job market and how online learning can help you acquire them.',
    comments: 12,
    image: 'blog post about career skills'
  },
  {
    id: '2',
    title: 'The Future of Online Education: Trends and Predictions',
    date: '2025-04-10',
    author: 'Maria Garcia',
    excerpt: 'Explore how technology is shaping the future of education and what it means for learners and educators.',
    comments: 8,
    image: 'blog post about online education trends'
  },
  {
    id: '3',
    title: 'Effective Time Management Strategies for Online Students',
    date: '2025-04-05',
    author: 'David Kim',
    excerpt: 'Learn practical tips and techniques to manage your time effectively while pursuing online courses.',
    comments: 22,
    image: 'blog post about time management'
  },
];

const HomeBlogSection = () => {
  return (
    <section className="section-padding bg-background">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row justify-between items-center mb-12"
        >
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Latest From Our Blog</h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Stay updated with the latest trends, tips, and insights in education and career development.
            </p>
          </div>
          <Link to="/blog">
            <Button variant="outline" className="mt-4 md:mt-0">
              View All Posts <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {mockBlogPosts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <BlogCard post={post} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HomeBlogSection;
