
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, Users, BookOpen, Award } from 'lucide-react';

const AboutSummary = () => {
  const stats = [
    { value: "10k+", label: "Active Students", icon: <Users className="h-6 w-6 text-primary" /> },
    { value: "1.2k+", label: "Online Courses", icon: <BookOpen className="h-6 w-6 text-primary" /> },
    { value: "250+", label: "Expert Instructors", icon: <Award className="h-6 w-6 text-primary" /> },
  ];

  return (
    <section className="section-padding bg-background">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="relative">
              <img 
                className="rounded-xl shadow-lg w-full h-auto object-cover aspect-[4/3]"
                alt="Team of educators collaborating"
               src="https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa" />
              <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-6 rounded-lg shadow-xl w-56">
                <h4 className="text-3xl font-bold">12+</h4>
                <p className="text-sm">Years of Experience in Education</p>
              </div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="space-y-6"
          >
            <span className="text-primary font-semibold">ABOUT DEVSDEEN</span>
            <h2 className="text-3xl md:text-4xl font-bold">
              Achieve Your Goals With DEVSDEEN
            </h2>
            <p className="text-muted-foreground text-lg">
              DEVSDEEN is a leading online learning platform dedicated to providing high-quality, accessible education for everyone. We believe in the power of knowledge to transform lives and are committed to helping you achieve your personal and professional goals.
            </p>
            <ul className="space-y-3">
              {[
                "Access to expert-led courses",
                "Flexible learning schedules",
                "Supportive student community",
                "Globally recognized certifications",
              ].map((item, index) => (
                <li key={index} className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-muted/50 rounded-lg">
                  {stat.icon}
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>
            <Link to="/about">
              <Button size="lg" className="mt-4 bg-primary hover:bg-primary/90 text-primary-foreground">Learn More About Us</Button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSummary;
