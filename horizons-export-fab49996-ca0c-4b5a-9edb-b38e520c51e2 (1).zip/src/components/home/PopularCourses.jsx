
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import CourseCard from '@/components/CourseCard'; 
import { ArrowRight } from 'lucide-react';

const mockCourses = [
  {
    id: '1',
    title: 'Introduction to Python Programming',
    category: 'Development',
    description: 'Learn the fundamentals of Python, one of the most popular programming languages.',
    instructor: { name: 'John Doe' },
    duration: '8 Weeks',
    students: 1203,
    level: 'Beginner',
    rating: 4.7,
    reviews: 250,
    image: 'python course illustration'
  },
  {
    id: '2',
    title: 'Digital Marketing Masterclass',
    category: 'Business',
    description: 'Master SEO, content marketing, social media, and more to grow your business.',
    instructor: { name: 'Jane Smith' },
    duration: '12 Weeks',
    students: 985,
    level: 'Intermediate',
    rating: 4.9,
    reviews: 412,
    image: 'digital marketing course illustration'
  },
  {
    id: '3',
    title: 'Graphic Design Fundamentals',
    category: 'Art & Design',
    description: 'Understand the core principles of graphic design and create stunning visuals.',
    instructor: { name: 'Alice Brown' },
    duration: '10 Weeks',
    students: 750,
    level: 'Beginner',
    rating: 4.6,
    reviews: 180,
    image: 'graphic design course illustration'
  },
];


const PopularCourses = () => {
  return (
    <section className="section-padding bg-muted/30">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row justify-between items-center mb-12"
        >
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Explore Our Popular Courses</h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Discover courses that are highly rated and in demand by learners worldwide.
            </p>
          </div>
          <Link to="/courses">
            <Button variant="outline" className="mt-4 md:mt-0">
              View All Courses <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {mockCourses.map((course, index) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <CourseCard course={course} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PopularCourses;
