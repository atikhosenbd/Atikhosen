
import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowRight, Search, Users, BookOpen, PlayCircle } from "lucide-react";

const Hero = () => {
  return (
    <section className="relative bg-secondary/30 section-padding overflow-hidden">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-foreground">
              Start Your Learning Journey with <span className="text-primary">DEVSDEEN</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl">
              Explore thousands of courses, taught by expert instructors. Achieve your goals with our flexible and engaging learning platform.
            </p>
            <div className="relative max-w-xl">
              <Input 
                type="text" 
                placeholder="What do you want to learn today?" 
                className="h-14 pl-12 pr-32 rounded-full text-base shadow-lg"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 h-10 rounded-full px-6 bg-primary hover:bg-primary/90 text-primary-foreground">
                Search
              </Button>
            </div>
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex -space-x-2">
                <img  className="inline-block h-10 w-10 rounded-full ring-2 ring-background object-cover" alt="Student 1" src="https://images.unsplash.com/photo-1581726690015-c9861fa5057f" />
                <img  className="inline-block h-10 w-10 rounded-full ring-2 ring-background object-cover" alt="Student 2" src="https://images.unsplash.com/photo-1700297427724-56439799016c" />
                <img  className="inline-block h-10 w-10 rounded-full ring-2 ring-background object-cover" alt="Student 3" src="https://images.unsplash.com/photo-1554716456-9bc4c4b91621" />
              </div>
              <p className="text-muted-foreground font-medium">
                Join <span className="text-primary font-bold">500K+</span> Students Worldwide
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="aspect-[4/3] relative">
              <img 
                className="rounded-xl shadow-2xl object-cover w-full h-full"
                alt="Hero image of diverse students learning"
               src="https://images.unsplash.com/photo-1698431048673-53ed1765ea07" />
              <div className="absolute -bottom-8 -left-8 bg-background p-4 rounded-lg shadow-xl flex items-center space-x-3 animate-fade-in animation-delay-1000">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-bold text-foreground">250+</p>
                  <p className="text-sm text-muted-foreground">Expert Instructors</p>
                </div>
              </div>
              <div className="absolute -top-8 -right-8 bg-background p-4 rounded-lg shadow-xl flex items-center space-x-3 animate-fade-in animation-delay-1500">
                <div className="p-3 bg-primary/10 rounded-full">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-bold text-foreground">1,200+</p>
                  <p className="text-sm text-muted-foreground">Online Courses</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-background/80 hover:bg-background rounded-full h-20 w-20 shadow-lg">
                <PlayCircle className="h-12 w-12 text-primary" />
              </Button>
            </div>
             <div className="absolute -top-16 -left-16 w-32 h-32 bg-primary/20 rounded-full filter blur-2xl animate-blob opacity-50"></div>
             <div className="absolute -bottom-16 -right-16 w-32 h-32 bg-green-500/20 rounded-full filter blur-2xl animate-blob animation-delay-2000 opacity-50"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
