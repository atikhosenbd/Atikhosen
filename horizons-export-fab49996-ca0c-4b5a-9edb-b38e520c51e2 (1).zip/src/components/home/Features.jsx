
import React from "react";
import { motion } from "framer-motion";
import { 
  Users, 
  BookOpen, 
  Calendar, 
  BarChart, 
  MessageSquare, 
  FileText 
} from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: <Users className="h-10 w-10 text-primary" />,
      title: "Student Management",
      description: "Maintain comprehensive student profiles with academic history, contact information, and performance metrics."
    },
    {
      icon: <BookOpen className="h-10 w-10 text-primary" />,
      title: "Course Management",
      description: "Create and manage courses, assign teachers, and track curriculum progress efficiently."
    },
    {
      icon: <Calendar className="h-10 w-10 text-primary" />,
      title: "Attendance Tracking",
      description: "Record and monitor student attendance with automated notifications for absences."
    },
    {
      icon: <BarChart className="h-10 w-10 text-primary" />,
      title: "Performance Analytics",
      description: "Generate detailed reports on student performance, identify trends, and track improvement areas."
    },
    {
      icon: <MessageSquare className="h-10 w-10 text-primary" />,
      title: "Communication Tools",
      description: "Facilitate seamless communication between administrators, teachers, students, and parents."
    },
    {
      icon: <FileText className="h-10 w-10 text-primary" />,
      title: "Document Management",
      description: "Store and organize important documents, certificates, and academic records securely."
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section className="py-20 bg-muted/50">
      <div className="container">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Comprehensive Features for Educational Excellence</h2>
          <p className="text-lg text-muted-foreground">
            Our student management system provides all the tools you need to streamline administrative tasks and enhance educational outcomes.
          </p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              className="bg-background rounded-xl p-8 shadow-sm border border-border hover:shadow-md transition-all duration-300 feature-card"
              variants={itemVariants}
            >
              <div className="mb-6 p-3 rounded-full bg-primary/10 inline-block">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Features;
