
import React from "react";
import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      content: "DEVSDEEN has been a game-changer for my career. The courses are top-notch and the instructors are incredibly knowledgeable. Highly recommended!",
      author: "Sarah Miller",
      role: "Software Engineer",
      avatar: "SM",
      rating: 5
    },
    {
      id: 2,
      content: "I was able to learn new skills at my own pace, which was perfect for my busy schedule. The platform is user-friendly and the support team is excellent.",
      author: "David Lee",
      role: "Marketing Manager",
      avatar: "DL",
      rating: 5
    },
    {
      id: 3,
      content: "The variety of courses available on DEVSDEEN is impressive. I've taken multiple courses and each one has exceeded my expectations. A fantastic learning resource!",
      author: "Jessica Chen",
      role: "Graphic Designer",
      avatar: "JC",
      rating: 4
    },
  ];

  return (
    <section className="section-padding bg-secondary/30">
      <div className="container">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Students Say</h2>
          <p className="text-lg text-muted-foreground">
            Hear from learners who have transformed their skills and careers with DEVSDEEN.
          </p>
        </motion.div>

        <div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {testimonials.map((testimonial, index) => (
            <motion.div 
              key={testimonial.id} 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full bg-background shadow-lg">
                <CardContent className="p-8 relative">
                  <Quote className="absolute top-6 left-6 h-10 w-10 text-primary/20 transform rotate-180" />
                  <div className="flex mb-4 mt-8">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-5 w-5 ${i < testimonial.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                      />
                    ))}
                  </div>
                  <p className="mb-6 text-muted-foreground italic text-base leading-relaxed">"{testimonial.content}"</p>
                  <div className="flex items-center pt-6 border-t border-border/50">
                    <Avatar className="h-12 w-12 mr-4">
                      <img  className="w-full h-full object-cover" alt={testimonial.author} src="https://images.unsplash.com/photo-1692108473356-f3fa604608e5" />
                      <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold text-foreground">{testimonial.author}</h4>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
