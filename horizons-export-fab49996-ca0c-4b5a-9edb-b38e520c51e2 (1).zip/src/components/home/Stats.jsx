
import React from "react";
import { motion } from "framer-motion";
import { Users, School, BookOpen, Award } from "lucide-react";

const Stats = () => {
  const stats = [
    {
      icon: <School className="h-8 w-8 text-primary" />,
      value: "500+",
      label: "Schools & Colleges",
      description: "Trust our platform"
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      value: "250,000+",
      label: "Students",
      description: "Managed efficiently"
    },
    {
      icon: <BookOpen className="h-8 w-8 text-primary" />,
      value: "15,000+",
      label: "Courses",
      description: "Organized & tracked"
    },
    {
      icon: <Award className="h-8 w-8 text-primary" />,
      value: "99.9%",
      label: "Uptime",
      description: "Reliable service"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section className="py-16 bg-muted">
      <div className="container">
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {stats.map((stat, index) => (
            <motion.div 
              key={index}
              className="bg-background rounded-xl p-6 text-center shadow-sm border border-border stat-card"
              variants={itemVariants}
            >
              <div className="flex justify-center mb-4">
                <div className="p-3 rounded-full bg-primary/10">
                  {stat.icon}
                </div>
              </div>
              <h3 className="text-3xl font-bold text-primary mb-2">{stat.value}</h3>
              <p className="font-medium mb-1">{stat.label}</p>
              <p className="text-sm text-muted-foreground">{stat.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Stats;
