
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Paintbrush, Code, BarChartBig, Atom, Music, Landmark } from 'lucide-react';

const categories = [
  { name: "Art & Design", icon: <Paintbrush className="h-8 w-8" />, courses: "120 Courses", color: "text-red-500", bgColor: "bg-red-100" },
  { name: "Development", icon: <Code className="h-8 w-8" />, courses: "250 Courses", color: "text-blue-500", bgColor: "bg-blue-100" },
  { name: "Business", icon: <BarChartBig className="h-8 w-8" />, courses: "180 Courses", color: "text-green-500", bgColor: "bg-green-100" },
  { name: "Science", icon: <Atom className="h-8 w-8" />, courses: "150 Courses", color: "text-purple-500", bgColor: "bg-purple-100" },
  { name: "Music", icon: <Music className="h-8 w-8" />, courses: "90 Courses", color: "text-yellow-500", bgColor: "bg-yellow-100" },
  { name: "Academics", icon: <Landmark className="h-8 w-8" />, courses: "300 Courses", color: "text-indigo-500", bgColor: "bg-indigo-100" },
];

const Categories = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section className="section-padding bg-background">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-3">Browse Top Categories</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore a wide range of subjects and find the perfect course to enhance your skills and knowledge.
          </p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {categories.map((category) => (
            <motion.div key={category.name} variants={itemVariants}>
              <Link to={`/courses?category=${category.name.toLowerCase().replace(' & ', '-')}`}>
                <Card className={`p-6 ${category.bgColor} hover:shadow-xl hover:scale-105 transition-all duration-300`}>
                  <div className={`mb-4 inline-block p-3 rounded-lg ${category.color}`}>
                    {category.icon}
                  </div>
                  <h3 className={`text-xl font-semibold mb-1 ${category.color}`}>{category.name}</h3>
                  <p className="text-sm text-muted-foreground">{category.courses}</p>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Categories;
