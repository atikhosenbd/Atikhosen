
import React from "react";
import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Mail, Phone } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Footer = () => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/fab49996-ca0c-4b5a-9edb-b38e520c51e2/741610e3dbce7bc5201f7d201b01c43b.png";
  return (
    <footer className="bg-secondary/50 border-t section-padding">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <img src={logoUrl} alt="DEVSDEEN Logo" className="h-8" />
            </Link>
            <p className="text-muted-foreground">
              Empowering learners and developers through innovative and accessible technology. Join our community and explore a world of knowledge.
            </p>
            <div className="flex space-x-3">
              {[Facebook, Twitter, Instagram, Linkedin, Youtube].map((Icon, index) => (
                <a key={index} href="#" className="text-muted-foreground hover:text-primary transition-colors p-2 rounded-full hover:bg-primary/10">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-6">Explore</h3>
            <ul className="space-y-3">
              {["About Us", "Courses", "Instructors", "Blog", "Contact Us"].map((text) => (
                <li key={text}>
                  <Link to={`/${text.toLowerCase().replace(" ", "-")}`} className="text-muted-foreground hover:text-primary transition-colors">
                    {text}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-6">Resources</h3>
            <ul className="space-y-3">
              {["Help Center", "FAQ", "Privacy Policy", "Terms of Service", "Sitemap"].map((text) => (
                 <li key={text}>
                 <Link to={`/${text.toLowerCase().replace(" ", "-")}`} className="text-muted-foreground hover:text-primary transition-colors">
                   {text}
                 </Link>
               </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-6">Newsletter</h3>
            <p className="text-muted-foreground mb-4">Stay updated with our latest courses and news.</p>
            <form className="flex gap-2">
              <Input type="email" placeholder="Your email" className="flex-1" />
              <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground">Subscribe</Button>
            </form>
            <div className="mt-6 space-y-3">
              <div className="flex items-center gap-2">
                <Mail size={18} className="text-primary" />
                <span className="text-sm text-muted-foreground">info@devsdeen.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone size={18} className="text-primary" />
                <span className="text-sm text-muted-foreground">(123) 456-7890</span>
              </div>
            </div>
          </div>
        </div>
        
        <Separator className="my-8 bg-border/50" />
        
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <p className="text-sm text-muted-foreground mb-4 md:mb-0">
            © {new Date().getFullYear()} DEVSDEEN. All Rights Reserved.
          </p>
          <div className="flex space-x-4">
             <Link to="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors">Privacy</Link>
             <Link to="/terms" className="text-sm text-muted-foreground hover:text-primary transition-colors">Terms</Link>
             <Link to="/sitemap" className="text-sm text-muted-foreground hover:text-primary transition-colors">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
